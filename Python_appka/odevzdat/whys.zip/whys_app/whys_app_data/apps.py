from django.apps import AppConfig


class WhysAppDataConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'whys_app_data'
